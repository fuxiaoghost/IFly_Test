//
//  MSCAppDelegate.h
//  MSCDemo
//
//  Created by iflytek on 13-6-5.
//  Copyright (c) 2013年 iflytek. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MSCViewController;

@interface MSCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MSCViewController *viewController;

@end
